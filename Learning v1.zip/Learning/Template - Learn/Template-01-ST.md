---
tags:
  - Strategy
  - learning
strategy_name: "{{VALUE:Topic}}"
related:
date_created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
watermark: "The MIT License (MIT) Copyright © 2025 Jaroslaw Ladosz"
---
# {{VALUE:Topic}}

## 📖 Technical Definition
> 

## 🏷️ Related Topics
- 

## 📝 My Definition
> 

## 🔗 Sources
- [Source 1]()
- [Source 2]() 

## 🖼️ Supporting Images
*(Drag and drop one or more images directly under this heading. Obsidian will automatically create the links.)*

---

## 🔗 Related Notes
- Use the backlinks pane or manually list notes that share relevant tags


<!-- "The MIT License (MIT) Copyright © 2025 Jaroslaw Ladosz" -->